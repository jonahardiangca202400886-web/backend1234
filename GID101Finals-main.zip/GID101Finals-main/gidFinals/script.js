const events = [
  {
    id: "sb19",
    title: "SB19 Simula at Wakas",
    date: "Feb 22, 2027",
    time: "07:00 PM",
    venue: "Araneta Coliseum, Quezon City",
    price: 1000,
    available: 99,
    category: "P-pop",
    image: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=1000&q=85",
    description: "Experience SB19 Simula at Wakas for an unforgettable night of music, emotion, and energy."
  },
  {
    id: "lany",
    title: "LANY Live in Manila",
    date: "Feb 20, 2027",
    time: "07:00 PM",
    venue: "Araneta Coliseum, Quezon City",
    price: 1500,
    available: 48,
    category: "Pop",
    image: "https://images.unsplash.com/photo-1506157786151-b8491531f063?auto=format&fit=crop&w=1000&q=85",
    description: "Sing along to the songs you love and make a night of it with LANY, live in Manila."
  },
  {
    id: "festival",
    title: "Neon Nights Music Festival",
    date: "Mar 14, 2027",
    time: "06:30 PM",
    venue: "Filinvest City Events Grounds",
    price: 1800,
    available: 126,
    category: "Festival",
    image: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&w=1000&q=85",
    description: "A night of live sets, bright lights, and unforgettable music from your favorite artists."
  },
  {
    id: "acoustic",
    title: "An Evening of OPM",
    date: "Mar 28, 2027",
    time: "08:00 PM",
    venue: "New Frontier Theater, Quezon City",
    price: 850,
    available: 72,
    category: "OPM",
    image: "https://images.unsplash.com/photo-1501612780327-45045538702b?auto=format&fit=crop&w=1000&q=85",
    description: "A warm, intimate evening celebrating the voices and songs of Filipino music."
  }
];

const icons = {
  arrow: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>',
  home: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg>',
  search: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.5 4.5"/></svg>',
  ticket: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7a2 2 0 0 0 0 4v2a2 2 0 0 0 0 4h16v-4a2 2 0 0 1 0-4V5H4z"/><path d="M13 5v2m0 3v2m0 3v2"/></svg>',
  user: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>',
  heart: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.8 8.8c0 5.2-8.8 10.1-8.8 10.1S3.2 14 3.2 8.8A4.5 4.5 0 0 1 12 6.5a4.5 4.5 0 0 1 8.8 2.3z"/></svg>',
  logout: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 17l5-5-5-5m5 5H3"/><path d="M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7"/></svg>',
  wifi: '<svg viewBox="0 0 24 20" aria-hidden="true"><path d="M2 7.5a15 15 0 0 1 20 0M5.5 11a10 10 0 0 1 13 0M9 14.5a5 5 0 0 1 6 0"/><path d="M12 18h.01"/></svg>',
  battery: '<svg viewBox="0 0 26 18" aria-hidden="true"><rect x="1" y="2" width="21" height="14" rx="3"/><path d="M24 7v4"/></svg>'
};

const state = {
  screen: "auth",
  authMode: "login",
  user: "",
  selectedEvent: events[0],
  ticketType: "Normal",
  quantity: 1,
  search: "",
  category: "All",
  wishlist: new Set()
};

const app = document.querySelector("#app");
const toast = document.querySelector("#toast");
let toastTimer;

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function imageMarkup(event, className = "") {
  return `<img class="${className}" src="${event.image}" alt="${escapeHtml(event.title)} live performance" loading="lazy">`;
}

function brandMarkup() {
  return `
    <div class="brand-lockup" aria-label="GigFinder">
      <div class="brand-mark">
        <svg viewBox="0 0 100 100" role="img" aria-label="GigFinder music pin">
          <defs>
            <linearGradient id="pin-gradient" x1="13%" y1="8%" x2="90%" y2="100%">
              <stop offset="0" stop-color="#f014df"/>
              <stop offset=".52" stop-color="#7834f1"/>
              <stop offset="1" stop-color="#08bdf1"/>
            </linearGradient>
          </defs>
          <path fill="url(#pin-gradient)" d="M50 4C29 4 12 21 12 42c0 25 38 53 38 53s38-28 38-53C88 21 71 4 50 4Zm0 57a20 20 0 1 1 0-40 20 20 0 0 1 0 40Z"/>
          <path fill="#08080a" d="M28 46h6l4-13 6 24 6-17 5 11 5-18 5 13h8v6h-12l-2-5-6 18-6-12-5 14-7-24-2 7H28z"/>
          <path fill="#09bde9" d="m64 49 24-7 4 17-24 7z"/>
        </svg>
      </div>
      <p class="wordmark"><span class="gig">Gig</span><span class="finder">Finder</span></p>
    </div>`;
}

function statusBar() {
  return `<div class="status-bar" aria-hidden="true">${icons.wifi}${icons.battery}</div>`;
}

function header(action = "profile") {
  const actionIcon = action === "wishlist" ? icons.heart : icons.user;
  const actionLabel = action === "wishlist" ? "Open wishlist" : "Open profile";
  return `
    <header class="app-header">
      <p class="wordmark"><span class="gig">Gig</span><span class="finder">Finder</span></p>
      <button class="header-action" type="button" data-action="${action}" aria-label="${actionLabel}">${actionIcon}</button>
    </header>`;
}

function tabBar(active) {
  return `
    <nav class="tabs" aria-label="Main navigation">
      <button class="tab-button ${active === "home" ? "active" : ""}" type="button" data-action="home">${icons.home}<span>Home</span></button>
      <button class="tab-button ${active === "explore" ? "active" : ""}" type="button" data-action="explore">${icons.search}<span>Explore</span></button>
      <button class="tab-button ${active === "wishlist" ? "active" : ""}" type="button" data-action="wishlist">${icons.ticket}<span>My tickets</span></button>
      <button class="tab-button ${active === "profile" ? "active" : ""}" type="button" data-action="profile">${icons.user}<span>Profile</span></button>
    </nav>`;
}

function eventCard(event) {
  return `
    <button class="event-card" type="button" data-action="open-event" data-id="${event.id}" aria-label="View ${escapeHtml(event.title)}">
      <span class="event-poster">${imageMarkup(event)}</span>
      <span class="event-info">
        <span class="event-date">${escapeHtml(event.date)}</span>
        <span class="event-name">${escapeHtml(event.title)}</span>
        <span class="event-location">${escapeHtml(event.venue)}</span>
        <span class="event-price">From ₱${event.price.toLocaleString("en-PH")}</span>
      </span>
    </button>`;
}

function filteredEvents() {
  const query = state.search.trim().toLowerCase();
  return events.filter(event => {
    const matchesText = !query || `${event.title} ${event.venue} ${event.category}`.toLowerCase().includes(query);
    const matchesCategory = state.category === "All" || event.category === state.category;
    return matchesText && matchesCategory;
  });
}

function authScreen() {
  const register = state.authMode === "register";
  return `
    <section class="screen auth-screen">
      <div class="scroll-area">
        ${brandMarkup()}
        <p class="tagline">Find Your Next Gig</p>
        <form class="auth-form" data-form="auth">
          ${register ? `
            <label class="field">
              <span class="field-label">Your name</span>
              <input name="name" autocomplete="name" placeholder="Enter your name" required>
            </label>` : ""}
          <label class="field">
            <span class="field-label">Email Address</span>
            <input name="email" type="email" autocomplete="email" placeholder="Enter your email" required>
          </label>
          <label class="field">
            <span class="field-label">Password</span>
            <input name="password" type="password" autocomplete="${register ? "new-password" : "current-password"}" minlength="4" placeholder="Enter your password" required>
          </label>
          ${register ? "" : `<button class="text-link" type="button" data-action="forgot-password">Forgot password?</button>`}
          <button class="primary-button" type="submit">${register ? "Create Account" : "Log In"}</button>
        </form>
        <p class="auth-switch">
          ${register ? "Already have an account?" : "New to GigFinder?"}
          <button class="text-link" type="button" data-action="toggle-auth">${register ? "Log in" : "Register"}</button>
        </p>
        <button class="text-link guest-link" type="button" data-action="home">Explore as guest</button>
      </div>
    </section>`;
}

function homeScreen() {
  const matches = filteredEvents();
  const featured = matches[0];
  const upcoming = matches.slice(1);
  return `
    <section class="screen">
      ${header("profile")}
      <div class="scroll-area home-content">
        <p class="welcome-line">${state.user ? `Welcome back, ${escapeHtml(state.user)}` : "Your next unforgettable night starts here"}</p>
        <h1 class="page-title">Discover Live<br>Music Events</h1>
        <label class="search-box">${icons.search}<input name="event-search" type="search" value="${escapeHtml(state.search)}" placeholder="Search events, artists, venues" aria-label="Search events, artists, or venues"></label>
        <div class="section-heading">
          <h2>Featured Gig</h2>
          <button type="button" data-action="explore">See all</button>
        </div>
        ${featured ? `
          <button class="featured-card" type="button" data-action="open-event" data-id="${featured.id}" aria-label="View ${escapeHtml(featured.title)}">
            <span class="featured-poster">${imageMarkup(featured)}</span>
            <span class="featured-copy">
              <span class="event-date">${escapeHtml(featured.date)} · ${escapeHtml(featured.time)}</span>
              <h3>${escapeHtml(featured.title)}</h3>
              <p>${escapeHtml(featured.venue)}</p>
            </span>
          </button>` : `<div class="empty-state"><p>No gigs found</p>Try a different search.</div>`}
        <div class="section-heading" style="margin-top:20px">
          <h2>${upcoming.length ? "Upcoming Gigs" : "More Gigs"}</h2>
          <button type="button" data-action="explore">View all</button>
        </div>
        <div class="event-list">${upcoming.map(eventCard).join("")}</div>
      </div>
      ${tabBar("home")}
    </section>`;
}

function exploreScreen() {
  const categories = ["All", ...new Set(events.map(event => event.category))];
  const results = filteredEvents();
  return `
    <section class="screen">
      ${header("wishlist")}
      <div class="scroll-area explore-content">
        <p class="welcome-line">Find the next show you'll remember</p>
        <h1 class="page-title">Explore Gigs</h1>
        <label class="search-box">${icons.search}<input name="event-search" type="search" value="${escapeHtml(state.search)}" placeholder="Search events, artists, venues" aria-label="Search events, artists, or venues"></label>
        <div class="category-row" aria-label="Filter by event type">
          ${categories.map(category => `<button class="category-chip ${state.category === category ? "active" : ""}" type="button" data-action="category" data-category="${escapeHtml(category)}">${escapeHtml(category)}</button>`).join("")}
        </div>
        <div class="section-heading"><h2>${results.length ? "Upcoming Gigs" : "No gigs found"}</h2></div>
        <div class="event-list">${results.map(eventCard).join("")}</div>
      </div>
      ${tabBar("explore")}
    </section>`;
}

function detailScreen() {
  const event = state.selectedEvent;
  const unitPrice = event.price + (state.ticketType === "VIP" ? 1000 : 0);
  const total = unitPrice * state.quantity;
  return `
    <section class="screen">
      ${statusBar()}
      <header class="detail-header">
        <button class="back-button" type="button" data-action="back" aria-label="Go back">${icons.arrow}</button>
        <h1>Event Details</h1>
        <button class="logout-button" type="button" data-action="logout">Logout</button>
      </header>
      <div class="scroll-area detail-content">
        <div class="detail-poster">${imageMarkup(event)}</div>
        <h2 class="detail-title">${escapeHtml(event.title)}</h2>
        <div class="detail-meta">
          <span>${escapeHtml(event.date)}</span><span>${escapeHtml(event.time)}</span>
          <span class="full">${escapeHtml(event.venue)}</span>
        </div>
        <div class="ticket-summary">
          <span>Ticket Price:</span><strong>₱ ${total.toLocaleString("en-PH")}.00</strong>
          <span>Available Tickets:</span><strong>${Math.max(0, event.available - state.quantity + 1)} Left</strong>
        </div>
        <div class="quantity-row">
          <span>Buy Tickets:</span>
          <span class="quantity-control">
            <button type="button" data-action="quantity" data-step="-1" aria-label="Remove one ticket" ${state.quantity <= 1 ? "disabled" : ""}>−</button>
            <output aria-label="Ticket quantity">${state.quantity}</output>
            <button type="button" data-action="quantity" data-step="1" aria-label="Add one ticket" ${state.quantity >= event.available ? "disabled" : ""}>+</button>
          </span>
        </div>
        <section class="about-panel">
          <h2>About the Event</h2>
          <p>${escapeHtml(event.description)}</p>
        </section>
        <div class="ticket-types" role="group" aria-label="Ticket type">
          <button class="ticket-type ${state.ticketType === "Normal" ? "active" : ""}" type="button" data-action="ticket-type" data-type="Normal" aria-pressed="${state.ticketType === "Normal"}">Normal</button>
          <button class="ticket-type ${state.ticketType === "VIP" ? "active" : ""}" type="button" data-action="ticket-type" data-type="VIP" aria-pressed="${state.ticketType === "VIP"}">VIP</button>
        </div>
        <div class="detail-actions">
          <button class="primary-button" type="button" data-action="book">Book/Buy Now</button>
          <button class="quiet-button" type="button" data-action="wishlist-toggle">${state.wishlist.has(event.id) ? "Added to Wishlist" : "Add to Wishlist"}</button>
        </div>
      </div>
    </section>`;
}

function confirmationScreen() {
  const event = state.selectedEvent;
  return `
    <section class="screen">
      ${statusBar()}
      <header class="detail-header">
        <button class="back-button" type="button" data-action="home" aria-label="Go to home">${icons.arrow}</button>
        <h1>Event Details</h1>
        <button class="logout-button" type="button" data-action="logout">Logout</button>
      </header>
      <div class="scroll-area confirmation-content">
        <div class="detail-poster">${imageMarkup(event)}</div>
        <h2 class="detail-title">${escapeHtml(event.title)}</h2>
        <div class="confirmation-meta"><span>${escapeHtml(event.date)}</span><span>${escapeHtml(event.time)}</span></div>
        <p class="confirmation-meta" style="align-self:start;margin:8px 0 0">${escapeHtml(event.venue)}</p>
        <p class="confirmation-message">${escapeHtml(state.ticketType)}<br>Congratulations<br>you buy ${state.quantity} Tickets</p>
        <button class="primary-button" type="button" data-action="home">Back to Gigs</button>
      </div>
    </section>`;
}

function profileScreen() {
  const name = state.user || "Music lover";
  return `
    <section class="screen">
      ${header("wishlist")}
      <div class="scroll-area profile-content">
        <p class="welcome-line">Your GigFinder account</p>
        <h1 class="page-title">My Profile</h1>
        <div class="profile-card" style="margin-top:18px">
          <div class="avatar" aria-hidden="true">${escapeHtml(name.charAt(0).toUpperCase())}</div>
          <h2>${escapeHtml(name)}</h2>
          <p>${state.user ? "Ready for your next live show" : "Browsing as a guest"}</p>
        </div>
        <div class="profile-actions">
          <button class="secondary-button" type="button" data-action="wishlist">${icons.heart} My Wishlist (${state.wishlist.size})</button>
          <button class="secondary-button" type="button" data-action="explore">${icons.ticket} Find an Event</button>
          ${state.user ? `<button class="quiet-button" type="button" data-action="logout">${icons.logout} Log Out</button>` : `<button class="primary-button" type="button" data-action="login">Log In</button>`}
        </div>
      </div>
      ${tabBar("profile")}
    </section>`;
}

function wishlistScreen() {
  const saved = events.filter(event => state.wishlist.has(event.id));
  return `
    <section class="screen">
      ${header("profile")}
      <div class="scroll-area explore-content">
        <p class="welcome-line">Your saved nights out</p>
        <h1 class="page-title">My Tickets</h1>
        <div class="section-heading" style="margin-top:20px"><h2>Wishlist</h2></div>
        ${saved.length
          ? `<div class="event-list">${saved.map(eventCard).join("")}</div>`
          : `<div class="empty-state"><p>No saved gigs yet</p><button class="text-link" type="button" data-action="explore">Explore upcoming shows</button></div>`}
      </div>
      ${tabBar("wishlist")}
    </section>`;
}

function render() {
  const screens = {
    auth: authScreen,
    home: homeScreen,
    explore: exploreScreen,
    detail: detailScreen,
    confirmation: confirmationScreen,
    profile: profileScreen,
    wishlist: wishlistScreen
  };
  app.innerHTML = screens[state.screen]();
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("visible"), 2400);
}

function openEvent(id) {
  const event = events.find(item => item.id === id);
  if (!event) {
    showToast("That event could not be found.");
    return;
  }
  state.selectedEvent = event;
  state.quantity = 1;
  state.ticketType = "Normal";
  state.screen = "detail";
  render();
}

function navigate(screen) {
  state.screen = screen;
  if (screen === "home" || screen === "explore") {
    state.search = "";
    state.category = "All";
  }
  render();
}

app.addEventListener("click", event => {
  const button = event.target.closest("[data-action]");
  if (!button || !app.contains(button)) return;

  const action = button.dataset.action;
  if (action === "home" || action === "explore" || action === "profile" || action === "wishlist") {
    navigate(action);
  } else if (action === "open-event") {
    openEvent(button.dataset.id);
  } else if (action === "back") {
    navigate("explore");
  } else if (action === "logout") {
    state.user = "";
    state.authMode = "login";
    navigate("auth");
  } else if (action === "login") {
    state.authMode = "login";
    navigate("auth");
  } else if (action === "toggle-auth") {
    state.authMode = state.authMode === "login" ? "register" : "login";
    render();
  } else if (action === "forgot-password") {
    showToast("Password reset is not available in this demo.");
  } else if (action === "category") {
    state.category = button.dataset.category;
    render();
  } else if (action === "quantity") {
    const next = state.quantity + Number(button.dataset.step);
    state.quantity = Math.min(state.selectedEvent.available, Math.max(1, next));
    render();
  } else if (action === "ticket-type") {
    state.ticketType = button.dataset.type;
    render();
  } else if (action === "wishlist-toggle") {
    const id = state.selectedEvent.id;
    if (state.wishlist.has(id)) {
      state.wishlist.delete(id);
      showToast("Removed from your wishlist");
    } else {
      state.wishlist.add(id);
      showToast("Added to your wishlist");
    }
    render();
  } else if (action === "book") {
    state.screen = "confirmation";
    render();
  }
});

app.addEventListener("submit", event => {
  if (event.target.dataset.form !== "auth") return;
  event.preventDefault();
  if (!event.target.reportValidity()) return;

  const formData = new FormData(event.target);
  const email = String(formData.get("email") || "").trim();
  const name = String(formData.get("name") || email.split("@")[0]).trim();
  if (!email || !name) {
    showToast("Enter your name and email to continue.");
    return;
  }
  state.user = name;
  navigate("home");
});

app.addEventListener("input", event => {
  if (event.target.name !== "event-search") return;
  const selectionStart = event.target.selectionStart;
  state.search = event.target.value;
  render();
  const input = app.querySelector('input[name="event-search"]');
  if (input) {
    input.focus();
    input.setSelectionRange(selectionStart, selectionStart);
  }
});

render();
